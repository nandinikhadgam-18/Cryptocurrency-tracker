import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts'

export default function PriceChart({ sparkline }) {
    if (!sparkline || sparkline.length === 0) return null

    // Transform sparkline array into objects for Recharts
    const data = sparkline.map((price, index) => ({
        time: index,
        price: price
    }))

    const isPositive = data[data.length - 1].price >= data[0].price
    const color = isPositive ? "#34d399" : "#f87171" // green-400 or red-400

    return (
        <div className="w-full h-full relative">
            <h3 className="text-slate-400 text-sm mb-4 absolute top-0 left-0">7 Day Price Trend</h3>
            <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data}>
                    <defs>
                        <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={color} stopOpacity={0.3} />
                            <stop offset="95%" stopColor={color} stopOpacity={0} />
                        </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.2} vertical={false} />
                    <XAxis dataKey="time" hide />
                    <YAxis
                        domain={['auto', 'auto']}
                        hide
                    />
                    <Tooltip
                        contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#f8fafc' }}
                        itemStyle={{ color: color }}
                        formatter={(value) => [`$${value.toLocaleString()}`, 'Price']}
                        labelFormatter={() => ''}
                    />
                    <Area
                        type="monotone"
                        dataKey="price"
                        stroke={color}
                        strokeWidth={2}
                        fillOpacity={1}
                        fill="url(#colorPrice)"
                    />
                </AreaChart>
            </ResponsiveContainer>
        </div>
    )
}
