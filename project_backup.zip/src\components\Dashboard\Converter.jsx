import { useState, useEffect } from 'react'
import { ArrowRightLeft } from 'lucide-react'
import axios from 'axios'

export default function Converter() {
    const [amount, setAmount] = useState(1)
    const [currency, setCurrency] = useState('bitcoin')
    const [result, setResult] = useState(0)
    const [loading, setLoading] = useState(false)
    const [coins, setCoins] = useState([])

    useEffect(() => {
        // Fetch top coins for the dropdown
        const fetchCoins = async () => {
            try {
                const { data } = await axios.get(
                    'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=20&page=1'
                )
                setCoins(data)
                // Set initial calculation
                if (data.length > 0) {
                    const btc = data.find(c => c.id === 'bitcoin')
                    if (btc) setResult(btc.current_price)
                }
            } catch (error) {
                console.error("Error fetching coins for converter:", error)
            }
        }
        fetchCoins()
    }, [])

    useEffect(() => {
        const calculate = () => {
            const selectedCoin = coins.find(c => c.id === currency)
            if (selectedCoin) {
                setResult(amount * selectedCoin.current_price)
            }
        }
        calculate()
    }, [amount, currency, coins])

    return (
        <div className="glass-panel p-6 rounded-2xl border border-white/5 mb-8">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <ArrowRightLeft className="text-blue-400" />
                Crypto Converter
            </h3>

            <div className="flex flex-col md:flex-row items-center gap-4">
                <div className="flex-1 w-full">
                    <label className="text-sm text-slate-400 mb-1 block">Amount</label>
                    <input
                        type="number"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        className="w-full bg-slate-800/50 border border-slate-700 rounded-lg p-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                    />
                </div>

                <div className="flex-1 w-full">
                    <label className="text-sm text-slate-400 mb-1 block">Crypto</label>
                    <select
                        value={currency}
                        onChange={(e) => setCurrency(e.target.value)}
                        className="w-full bg-slate-800/50 border border-slate-700 rounded-lg p-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 appearance-none cursor-pointer"
                    >
                        {coins.map(coin => (
                            <option key={coin.id} value={coin.id}>
                                {coin.name} ({coin.symbol.toUpperCase()})
                            </option>
                        ))}
                    </select>
                </div>

                <div className="text-slate-400 pt-6">=</div>

                <div className="flex-1 w-full">
                    <label className="text-sm text-slate-400 mb-1 block">USD Value</label>
                    <div className="w-full bg-slate-900/50 border border-slate-800 rounded-lg p-3 text-green-400 font-mono font-bold text-lg">
                        ${result.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </div>
                </div>
            </div>
        </div>
    )
}
