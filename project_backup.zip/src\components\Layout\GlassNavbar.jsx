import { Search, Rocket } from 'lucide-react'
import { useState } from 'react'
import WalletConnect from './WalletConnect'

export default function GlassNavbar({ onSearch, onWalletConnect }) {
    return (
        <nav className="sticky top-0 z-50 glass-nav px-4 py-3">
            <div className="container mx-auto flex items-center justify-between">
                <div className="flex items-center gap-2 group cursor-pointer">
                    <div className="p-2 rounded-full bg-blue-500/20 group-hover:bg-blue-500/30 transition-colors">
                        <Rocket className="w-6 h-6 text-blue-400 group-hover:animate-pulse" />
                    </div>
                    <span className="text-xl font-bold tracking-tight">
                        Crypto<span className="text-blue-400">Pulse</span>
                    </span>
                </div>

                <div className="relative hidden md:block w-96">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Search className="h-4 w-4 text-slate-400" />
                    </div>
                    <input
                        type="text"
                        placeholder="Search coins..."
                        className="w-full bg-slate-800/50 border border-slate-700 rounded-full py-2 pl-10 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-transparent transition-all placeholder:text-slate-500"
                        onChange={(e) => onSearch(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && e.preventDefault()}
                    />
                </div>

                <div className="flex items-center gap-4">
                    <div className="hidden sm:flex items-center gap-2 text-xs text-green-400 bg-green-900/20 px-3 py-1 rounded-full border border-green-500/20">
                        <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                        Market Live
                    </div>
                    <WalletConnect onConnect={onWalletConnect} />
                </div>
            </div>
        </nav>
    )
}
