import { motion } from 'framer-motion'
import { TrendingUp, TrendingDown } from 'lucide-react'

export default function CryptoCard({ coin, onClick }) {
    const isPositive = coin.price_change_percentage_24h > 0

    return (
        <motion.div
            layoutId={coin.id}
            whileHover={{ scale: 1.05, y: -10, rotateX: 5, rotateY: 5 }}
            whileTap={{ scale: 0.95 }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-panel rounded-xl p-4 cursor-pointer relative overflow-hidden group border border-white/5 hover:border-white/20 transition-all"
            onClick={() => onClick(coin)}
        >
            <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
                <img src={coin.image} alt={coin.name} className="w-24 h-24 rotate-[-15deg]" />
            </div>

            <div className="relative z-10 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <img src={coin.image} alt={coin.name} className="w-10 h-10 rounded-full" />
                    <div>
                        <h3 className="font-bold text-lg leading-tight">{coin.name}</h3>
                        <span className="text-xs font-mono text-slate-400 uppercase">{coin.symbol}</span>
                    </div>
                </div>
            </div>

            <div className="mt-4 relative z-10">
                <div className="flex items-end justify-between">
                    <span className="text-xl font-bold tracking-wide">
                        ${coin.current_price.toLocaleString()}
                    </span>
                    <div className={`flex items-center gap-1 text-sm font-medium ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {isPositive ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
                        {coin.price_change_percentage_24h.toFixed(2)}%
                    </div>
                </div>
            </div>

            <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
        </motion.div>
    )
}
