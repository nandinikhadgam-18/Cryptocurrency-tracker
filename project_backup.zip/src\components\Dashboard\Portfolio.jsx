import { useState, useEffect } from 'react'
import { Plus, Trash2, Wallet } from 'lucide-react'
import axios from 'axios'

export default function Portfolio({ simulatedData }) {
    const [holdings, setHoldings] = useState(() => {
        const saved = localStorage.getItem('crypto_portfolio')
        return saved ? JSON.parse(saved) : []
    })

    // Listen for simulation data changes
    useEffect(() => {
        if (simulatedData) {
            setHoldings(prev => {
                // Merge or replace? For demo, let's replace to show "import" effect clearly
                return simulatedData
            })
        }
    }, [simulatedData])

    const [coins, setCoins] = useState([])
    const [selectedCoin, setSelectedCoin] = useState('bitcoin')
    const [amount, setAmount] = useState('')
    const [prices, setPrices] = useState({})

    // Fetch coin list for dropdown and current prices
    useEffect(() => {
        const fetchMarket = async () => {
            try {
                const { data } = await axios.get(
                    'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=50&page=1'
                )
                setCoins(data)
                const priceMap = {}
                data.forEach(c => priceMap[c.id] = { price: c.current_price, image: c.image, symbol: c.symbol, name: c.name, change: c.price_change_percentage_24h })
                setPrices(priceMap)
            } catch (error) {
                console.error("Error loading portfolio data, using fallback", error)
                // Fallback Data for Demo Sustainability
                const fallbackData = [
                    { id: 'bitcoin', symbol: 'btc', name: 'Bitcoin', current_price: 52000, price_change_percentage_24h: 2.5, image: 'https://assets.coingecko.com/coins/images/1/large/bitcoin.png' },
                    { id: 'ethereum', symbol: 'eth', name: 'Ethereum', current_price: 2800, price_change_percentage_24h: 1.2, image: 'https://assets.coingecko.com/coins/images/279/large/ethereum.png' },
                    { id: 'solana', symbol: 'sol', name: 'Solana', current_price: 110, price_change_percentage_24h: -0.5, image: 'https://assets.coingecko.com/coins/images/4128/large/solana.png' },
                    { id: 'cardano', symbol: 'ada', name: 'Cardano', current_price: 0.55, price_change_percentage_24h: 0.8, image: 'https://assets.coingecko.com/coins/images/975/large/cardano.png' },
                    { id: 'ripple', symbol: 'xrp', name: 'XRP', current_price: 0.58, price_change_percentage_24h: -1.1, image: 'https://assets.coingecko.com/coins/images/44/large/xrp-symbol-white-128.png' }
                ]
                setCoins(fallbackData)
                const priceMap = {}
                fallbackData.forEach(c => priceMap[c.id] = { price: c.current_price, image: c.image, symbol: c.symbol, name: c.name, change: c.price_change_percentage_24h })
                setPrices(priceMap)
            }
        }
        fetchMarket()
    }, [])

    // Save to local storage
    useEffect(() => {
        localStorage.setItem('crypto_portfolio', JSON.stringify(holdings))
    }, [holdings])

    const addHolding = () => {
        if (!amount || parseFloat(amount) <= 0) return
        const newHolding = { id: selectedCoin, amount: parseFloat(amount) }
        // Check if exists
        const existingIndex = holdings.findIndex(h => h.id === selectedCoin)
        if (existingIndex >= 0) {
            const updated = [...holdings]
            updated[existingIndex].amount += parseFloat(amount)
            setHoldings(updated)
        } else {
            setHoldings([...holdings, newHolding])
        }
        setAmount('')
    }

    const removeHolding = (id) => {
        setHoldings(holdings.filter(h => h.id !== id))
    }

    const totalValue = holdings.reduce((acc, curr) => {
        const price = prices[curr.id]?.price || 0
        return acc + (price * curr.amount)
    }, 0)

    return (
        <div className="glass-panel p-6 rounded-2xl border border-white/5 h-full">
            <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                <Wallet className="text-purple-400" />
                My Portfolio
            </h3>

            <div className="flex gap-2 mb-6">
                <select
                    value={selectedCoin}
                    onChange={(e) => setSelectedCoin(e.target.value)}
                    className="bg-slate-800/50 border border-slate-700 rounded-lg p-2 flex-grow text-sm focus:outline-none"
                >
                    {coins.map(c => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                </select>
                <input
                    type="number"
                    placeholder="Qty"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && addHolding()}
                    className="w-24 bg-slate-800/50 border border-slate-700 rounded-lg p-2 text-sm focus:outline-none"
                />
                <button
                    onClick={addHolding}
                    className="bg-purple-500 hover:bg-purple-600 p-2 rounded-lg transition-colors"
                >
                    <Plus size={20} />
                </button>
            </div>

            <div className="mb-6 p-4 bg-purple-500/10 rounded-xl border border-purple-500/20 text-center">
                <div className="text-slate-400 text-sm uppercase tracking-wider">Total Balance</div>
                <div className="text-3xl font-bold text-white shadow-glow">
                    ${totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
            </div>

            <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                {holdings.length === 0 && <div className="text-slate-600 text-center py-4">No assets added</div>}
                {holdings.map(h => {
                    const data = prices[h.id]
                    if (!data) return null
                    const value = h.amount * data.price
                    return (
                        <div key={h.id} className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg border border-white/5 hover:border-white/10 transition-colors">
                            <div className="flex items-center gap-3">
                                <img src={data.image} alt={data.name} className="w-8 h-8 rounded-full" />
                                <div>
                                    <div className="font-bold text-sm">{data.symbol.toUpperCase()}</div>
                                    <div className="text-xs text-slate-400">{h.amount} coins</div>
                                </div>
                            </div>
                            <div className="text-right">
                                <div className="font-bold text-sm">${value.toLocaleString(undefined, { maximumFractionDigits: 1 })}</div>
                                <div className={`text-xs ${data.change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                    {data.change?.toFixed(1)}%
                                </div>
                            </div>
                            <button onClick={() => removeHolding(h.id)} className="text-slate-500 hover:text-red-400 transition-colors">
                                <Trash2 size={16} />
                            </button>
                        </div>
                    )
                })}
            </div>
        </div>
    )
}
