import { Canvas, useFrame } from '@react-three/fiber'
import { Float, Text, ContactShadows, Environment } from '@react-three/drei'
import { useRef, Suspense } from 'react'
import { motion } from 'framer-motion'

function FloatingCoin({ position, color, symbol, delay }) {
    const mesh = useRef()

    useFrame((state) => {
        const t = state.clock.getElapsedTime()
        mesh.current.rotation.y = Math.sin(t * 0.5 + delay) * 0.2
        mesh.current.rotation.x = Math.cos(t * 0.3 + delay) * 0.1
        mesh.current.position.y = position[1] + Math.sin(t + delay) * 0.1
    })

    return (
        <group ref={mesh} position={position}>
            <mesh>
                <cylinderGeometry args={[1, 1, 0.2, 32]} />
                <meshStandardMaterial color={color} metalness={0.8} roughness={0.2} />
            </mesh>
            <mesh position={[0, 0, 0.11]}>
                <cylinderGeometry args={[0.9, 0.9, 0.05, 32]} />
                <meshStandardMaterial color={color} metalness={0.6} roughness={0.4} />
            </mesh>
            <Text
                position={[0, 0, 0.15]}
                fontSize={0.6}
                color="white"
                anchorX="center"
                anchorY="middle"
                font="https://fonts.gstatic.com/s/inter/v12/UcCO3FwrK3iLTeHuS_fvQtMwCp50KnMw2boKoduKmMEVuLyfAZ9hjp-Ek-_EeA.woff"
            >
                {symbol}
            </Text>
        </group>
    )
}

function Scene() {
    return (
        <>
            <ambientLight intensity={1} />
            <pointLight position={[10, 10, 10]} intensity={1.5} color="#38bdf8" />
            <Float speed={2} rotationIntensity={1} floatIntensity={2}>
                <FloatingCoin position={[-2.5, 0, 0]} color="#F7931A" symbol="₿" delay={0} />
                <FloatingCoin position={[0, 0.5, 1]} color="#627EEA" symbol="Ξ" delay={2} />
                <FloatingCoin position={[2.5, -0.2, -0.5]} color="#26A17B" symbol="₮" delay={4} />
            </Float>
            <ContactShadows position={[0, -2, 0]} opacity={0.4} scale={20} blur={2.5} far={4} />
            <Environment preset="city" />
        </>
    )
}

export default function GravityHero() {
    return (
        <div className="relative w-full h-[400px] mb-8 rounded-3xl overflow-hidden glass-panel border-none">
            <div className="absolute inset-0 z-0">
                <Canvas camera={{ position: [0, 0, 6], fov: 45 }}>
                    <Suspense fallback={null}>
                        <Scene />
                    </Suspense>
                </Canvas>
            </div>

            <div className="absolute inset-0 z-10 flex flex-col items-center justify-center pointer-events-none">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8 }}
                    className="text-center"
                >
                    <h1 className="text-5xl md:text-7xl font-bold bg-clip-text text-transparent bg-gradient-to-b from-white to-white/50 drop-shadow-lg">
                        Zero Gravity
                    </h1>
                    <p className="mt-4 text-blue-200/80 text-lg tracking-wide uppercase font-light">
                        Next Gen Crypto Tracking
                    </p>
                </motion.div>
            </div>
        </div>
    )
}
