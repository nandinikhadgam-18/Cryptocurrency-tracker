import { useState } from 'react'
import { Wallet } from 'lucide-react'

export default function WalletConnect({ onConnect }) {
    const [walletAddress, setWalletAddress] = useState('')

    const connectWallet = async () => {
        if (typeof window.ethereum !== 'undefined') {
            try {
                const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' })
                setWalletAddress(accounts[0])
                if (onConnect) onConnect(accounts[0])
            } catch (error) {
                console.error("User denied connection", error)
            }
        } else {
            alert("MetaMask is not installed! Please install it to use this feature.")
        }
    }

    return (
        <button
            onClick={connectWallet}
            className={`
        flex items-center gap-2 px-4 py-2 rounded-full font-medium transition-all
        ${walletAddress
                    ? 'bg-gradient-to-r from-emerald-500/20 to-teal-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg hover:shadow-blue-500/25'
                }
      `}
        >
            <Wallet size={18} />
            {walletAddress
                ? `${walletAddress.substring(0, 6)}...${walletAddress.substring(38)}`
                : 'Connect Wallet'
            }
        </button>
    )
}
