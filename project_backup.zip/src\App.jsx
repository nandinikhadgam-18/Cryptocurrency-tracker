import { useState } from 'react'
import GlassNavbar from './components/Layout/GlassNavbar'
import GravityHero from './components/Hero/GravityHero'
import CryptoList from './components/Dashboard/CryptoList'
import TrendingTicker from './components/Dashboard/TrendingTicker'
import Converter from './components/Dashboard/Converter'
import Portfolio from './components/Dashboard/Portfolio'

function App() {
    const [searchTerm, setSearchTerm] = useState('')
    const [demoPortfolio, setDemoPortfolio] = useState(null)

    const handleWalletConnect = (address) => {
        // Simulate fetching portfolio data
        const simulatedData = [
            { id: 'bitcoin', amount: 0.45 },
            { id: 'ethereum', amount: 2.1 },
            { id: 'solana', amount: 15.5 },
            { id: 'cardano', amount: 1200 }
        ]
        setDemoPortfolio(simulatedData)
    }

    return (
        <div className="min-h-screen relative overflow-hidden bg-nordic-bg text-white">
            {/* Background Gradients */}
            <div className="fixed inset-0 z-0 pointer-events-none">
                <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-500/20 rounded-full blur-[120px]" />
                <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-500/20 rounded-full blur-[120px]" />
            </div>

            <div className="relative z-10 flex flex-col min-h-screen">
                <GlassNavbar onSearch={setSearchTerm} onWalletConnect={handleWalletConnect} />
                <TrendingTicker />

                <main className="flex-grow container mx-auto px-4 py-8">
                    <GravityHero />

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
                        <div className="lg:col-span-2">
                            <div className="glass-panel rounded-2xl p-6 border border-white/5">
                                <h2 className="text-2xl font-bold mb-6 bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">
                                    Live Market Data
                                </h2>
                                <CryptoList searchTerm={searchTerm} />
                            </div>
                        </div>

                        <div className="space-y-8">
                            <Portfolio simulatedData={demoPortfolio} />
                            <Converter />
                        </div>
                    </div>
                </main>

                <footer className="py-6 text-center text-slate-500 text-sm glass-nav mt-8">
                    <p>© 2024 Crypto Pulse | Anti-Gravity Tracker</p>
                </footer>
            </div>
        </div>
    )
}

export default App
