import { useState, useEffect } from 'react'
import axios from 'axios'
import CryptoCard from './CryptoCard'
import PriceChart from '../Details/PriceChart'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Loader2 } from 'lucide-react'

export default function CryptoList({ searchTerm }) {
    const [coins, setCoins] = useState([])
    const [loading, setLoading] = useState(true)
    const [selectedCoin, setSelectedCoin] = useState(null)

    useEffect(() => {
        const fetchCoins = async () => {
            try {
                const { data } = await axios.get(
                    'https://api.coingecko.com/api/v3/coins/markets', {
                    params: {
                        vs_currency: 'usd',
                        order: 'market_cap_desc',
                        per_page: 50,
                        page: 1,
                        sparkline: true,
                        price_change_percentage: '24h'
                    }
                }
                )
                setCoins(data)
                setLoading(false)
            } catch (error) {
                console.error("Error fetching data, using fallback:", error)
                // Robust Fallback Data
                const fallbackCoins = [
                    { id: 'bitcoin', symbol: 'btc', name: 'Bitcoin', current_price: 52000, price_change_percentage_24h: 2.5, image: 'https://assets.coingecko.com/coins/images/1/large/bitcoin.png', market_cap: 1000000000, total_volume: 500000000, high_24h: 53000, low_24h: 51000, sparkline_in_7d: { price: [51000, 51500, 51200, 52000, 51800, 52500, 52000] } },
                    { id: 'ethereum', symbol: 'eth', name: 'Ethereum', current_price: 2800, price_change_percentage_24h: 1.2, image: 'https://assets.coingecko.com/coins/images/279/large/ethereum.png', market_cap: 300000000, total_volume: 200000000, high_24h: 2850, low_24h: 2750, sparkline_in_7d: { price: [2700, 2750, 2720, 2800, 2780, 2820, 2800] } },
                    { id: 'solana', symbol: 'sol', name: 'Solana', current_price: 110, price_change_percentage_24h: -0.5, image: 'https://assets.coingecko.com/coins/images/4128/large/solana.png', market_cap: 50000000, total_volume: 30000000, high_24h: 115, low_24h: 108, sparkline_in_7d: { price: [105, 108, 112, 110, 109, 111, 110] } },
                    { id: 'binancecoin', symbol: 'bnb', name: 'BNB', current_price: 380, price_change_percentage_24h: 0.5, image: 'https://assets.coingecko.com/coins/images/825/large/bnb-icon2_2x.png', market_cap: 60000000, total_volume: 40000000, high_24h: 385, low_24h: 375, sparkline_in_7d: { price: [370, 375, 380, 378, 382, 380, 380] } },
                    { id: 'ripple', symbol: 'xrp', name: 'XRP', current_price: 0.58, price_change_percentage_24h: -1.1, image: 'https://assets.coingecko.com/coins/images/44/large/xrp-symbol-white-128.png', market_cap: 30000000, total_volume: 20000000, high_24h: 0.60, low_24h: 0.55, sparkline_in_7d: { price: [0.55, 0.56, 0.58, 0.57, 0.59, 0.58, 0.58] } }
                ]
                setCoins(fallbackCoins)
                setLoading(false)
            }
        }

        fetchCoins()
        const interval = setInterval(fetchCoins, 60000) // Refresh every minute
        return () => clearInterval(interval)
    }, [])

    const filteredCoins = coins.filter(coin =>
        coin.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        coin.symbol.toLowerCase().includes(searchTerm.toLowerCase())
    )

    if (loading) {
        return (
            <div className="flex flex-col items-center justify-center p-12 text-blue-400/80">
                <Loader2 className="w-10 h-10 animate-spin mb-4" />
                <p className="animate-pulse">Loading Market Data...</p>
            </div>
        )
    }

    return (
        <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredCoins.map((coin) => (
                    <CryptoCard key={coin.id} coin={coin} onClick={setSelectedCoin} />
                ))}
            </div>

            <AnimatePresence>
                {selectedCoin && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
                        onClick={() => setSelectedCoin(null)}
                    >
                        <motion.div
                            layoutId={selectedCoin.id}
                            className="w-full max-w-4xl bg-slate-900 border border-slate-700 rounded-2xl overflow-hidden shadow-2xl relative"
                            onClick={e => e.stopPropagation()}
                        >
                            <button
                                onClick={() => setSelectedCoin(null)}
                                className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 transition-colors z-50"
                            >
                                <X size={20} />
                            </button>

                            <div className="p-6 md:p-8">
                                <div className="flex items-center gap-4 mb-8">
                                    <img src={selectedCoin.image} alt={selectedCoin.name} className="w-16 h-16" />
                                    <div>
                                        <h2 className="text-3xl font-bold text-white">{selectedCoin.name}</h2>
                                        <span className="text-blue-400 font-mono text-xl">{selectedCoin.symbol.toUpperCase()}</span>
                                    </div>
                                    <div className="ml-auto text-right">
                                        <div className="text-3xl font-bold">${selectedCoin.current_price.toLocaleString()}</div>
                                        <div className={selectedCoin.price_change_percentage_24h > 0 ? "text-green-400" : "text-red-400"}>
                                            {selectedCoin.price_change_percentage_24h.toFixed(2)}% (24h)
                                        </div>
                                    </div>
                                </div>

                                <div className="h-[400px] w-full">
                                    <PriceChart sparkline={selectedCoin.sparkline_in_7d.price} />
                                </div>

                                <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
                                    <StatCard label="Market Cap" value={`$${selectedCoin.market_cap.toLocaleString()}`} />
                                    <StatCard label="Volume (24h)" value={`$${selectedCoin.total_volume.toLocaleString()}`} />
                                    <StatCard label="High 24h" value={`$${selectedCoin.high_24h.toLocaleString()}`} />
                                    <StatCard label="Low 24h" value={`$${selectedCoin.low_24h.toLocaleString()}`} />
                                </div>
                            </div>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </>
    )
}

function StatCard({ label, value }) {
    return (
        <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700/50">
            <div className="text-slate-400 text-sm mb-1">{label}</div>
            <div className="font-semibold text-white truncate" title={value}>{value}</div>
        </div>
    )
}
