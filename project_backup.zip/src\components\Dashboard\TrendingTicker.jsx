import { useEffect, useState } from 'react'
import axios from 'axios'
import { motion } from 'framer-motion'
import { Flame } from 'lucide-react'

export default function TrendingTicker() {
    const [trending, setTrending] = useState([])

    useEffect(() => {
        const fetchTrending = async () => {
            try {
                const { data } = await axios.get('https://api.coingecko.com/api/v3/search/trending')
                setTrending(data.coins)
            } catch (error) {
                console.error("Error fetching trending:", error)
            }
        }
        fetchTrending()
    }, [])

    if (trending.length === 0) return null

    return (
        <div className="w-full bg-slate-900/50 border-b border-white/5 backdrop-blur-sm overflow-hidden flex items-center h-10">
            <div className="px-4 flex items-center gap-2 text-orange-400 text-xs font-bold uppercase tracking-wider z-10 bg-slate-900/80 h-full shadow-xl">
                <Flame size={14} className="fill-orange-400 animate-pulse" />
                Trending
            </div>

            <div className="flex overflow-hidden relative w-full">
                <motion.div
                    className="flex items-center gap-8 whitespace-nowrap px-4"
                    animate={{ x: ["0%", "-50%"] }}
                    transition={{ repeat: Infinity, duration: 20, ease: "linear" }}
                >
                    {/* Duplicate list for seamless loop */}
                    {[...trending, ...trending].map((coin, i) => (
                        <div key={`${coin.item.id}-${i}`} className="flex items-center gap-2 text-xs font-medium text-slate-300">
                            <img src={coin.item.thumb} alt={coin.item.name} className="w-4 h-4 rounded-full" />
                            <span className="text-white">{coin.item.symbol}</span>
                            {coin.item.data.price_change_percentage_24h.usd && (
                                <span className={coin.item.data.price_change_percentage_24h.usd > 0 ? "text-green-400" : "text-red-400"}>
                                    {coin.item.data.price_change_percentage_24h.usd.toFixed(1)}%
                                </span>
                            )}
                        </div>
                    ))}
                </motion.div>
            </div>
        </div>
    )
}
